import { EventEmitter, Injectable, Output } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/compat/firestore';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { getAuth, onAuthStateChanged } from "firebase/auth";
// import { EventEmitter } from 'stream';
export interface Item { name: string; }

@Injectable({
  providedIn: 'root'
})
export class ConService {

  @Output() open: EventEmitter<any> = new EventEmitter();

  private itemsCollection: AngularFirestoreCollection<Item>;
  // private itemDoc: AngularFirestoreDocument<Item>;
  uid: any;
  items: Observable<Item[]>;
  // item: Observable<Item>;

  constructor(private afs: AngularFirestore) {

    const auth = getAuth();
    onAuthStateChanged(auth, (user) => {
      if (user) {
        // User is signed in, see docs for a list of available properties
        // https://firebase.google.com/docs/reference/js/firebase.User
        const uid = user.uid;
        this.uid = uid;
        // ...
      } else {
        // User is signed out
        // ...
      }
    });

    this.itemsCollection = afs.collection<Item>('Psicólogos');//.doc(this.uid).collection('Pacientes');
    this.items = this.itemsCollection.snapshotChanges().pipe(
      map(actions => actions.map(a => {
        const data = a.payload.doc.data() as Item;
        const id = a.payload.doc.id;
        return { id, ...data };
      }))
    );

    // this.itemDoc = afs.doc<Item>('T6bbPttK2EZJSsUDa4Y3jT68dOC2');
    // this.item = this.itemDoc.collection();
    // .valueChanges();
  }
  returnItems() {
    return this.items;
  }
  // returnItem(){
  //   return this.item;
  // }
}



