import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-consulta',
  templateUrl: './dashboard-consulta.component.html',
  styleUrls: ['./dashboard-consulta.component.css']
})
export class DashboardConsultaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
