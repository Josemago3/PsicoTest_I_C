import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-inicio',
  templateUrl: './dashboard-inicio.component.html',
  styleUrls: ['./dashboard-inicio.component.css']
})
export class DashboardInicioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
