export const environment = {
  firebase: {
    projectId: 'psicotest-92564',
    appId: '1:156325345609:web:16e7315ae787a369d7c298',
    databaseURL: 'https://psicotest-92564-default-rtdb.firebaseio.com',
    storageBucket: 'psicotest-92564.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyDRJguks3qQU9DYTHI6CCLMb29u_8v2O0c',
    authDomain: 'psicotest-92564.firebaseapp.com',
    messagingSenderId: '156325345609',
    measurementId: 'G-J0PE4LEVLQ',
  },
  production: true
};
